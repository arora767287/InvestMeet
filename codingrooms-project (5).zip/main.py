print("Hello, world! This is Python 3!")

